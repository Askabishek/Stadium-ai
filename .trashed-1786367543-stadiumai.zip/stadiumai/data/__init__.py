"""StadiumAI Data Package."""
